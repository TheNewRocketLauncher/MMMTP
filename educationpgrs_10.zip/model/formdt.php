<a href="home.php?click=1" class="btn">Click me</a>
<?php 
  if($_GET['click']){
    hello();
  }
?>